<?php

namespace App\Filament\Resources\LogSymptomResource\Pages;

use App\Filament\Resources\LogSymptomResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListLogSymptoms extends ListRecords
{
    protected static string $resource = LogSymptomResource::class;


}
