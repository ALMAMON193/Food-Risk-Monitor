<?php

namespace App\Filament\Resources\LogSymptomResource\Pages;

use App\Filament\Resources\LogSymptomResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLogSymptom extends CreateRecord
{
    protected static string $resource = LogSymptomResource::class;
}
