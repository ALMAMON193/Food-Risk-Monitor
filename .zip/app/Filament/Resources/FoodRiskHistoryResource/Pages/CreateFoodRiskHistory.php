<?php

namespace App\Filament\Resources\FoodRiskHistoryResource\Pages;

use App\Filament\Resources\FoodRiskHistoryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFoodRiskHistory extends CreateRecord
{
    protected static string $resource = FoodRiskHistoryResource::class;
}
