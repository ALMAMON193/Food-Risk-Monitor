<?php

namespace App\Filament\Resources\FoodRiskHistoryResource\Pages;

use App\Filament\Resources\FoodRiskHistoryResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListFoodRiskHistories extends ListRecords
{
    protected static string $resource = FoodRiskHistoryResource::class;


}
