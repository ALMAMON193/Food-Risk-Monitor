<?php

namespace App\Models\Controller\API;

use Illuminate\Database\Eloquent\Model;

class LogSymptomsController extends Model
{
    //
}
